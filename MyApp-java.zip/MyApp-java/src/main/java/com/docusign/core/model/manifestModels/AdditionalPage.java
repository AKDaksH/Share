package com.docusign.core.model.manifestModels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdditionalPage {
    public String Name;

    public String ResultsPageText;
}
