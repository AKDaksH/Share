package com.docusign.core.model.manifestModels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectAPIPage {
    public String SelectAPIHeader;

    public String SelectAPIButton;
}
